require_relative 'input_check'

class Test

  #object1 = InputCheck.new
  #object1.check_input(0)

  #object2 = InputCheck.new
  #object2.check_input("hello")

  #arr1 = ["harry" , "jen" , "lou"]
  #puts arr1.first(5 , 7)

  puts "Hi ... last line of code....."

end

# Handle multiple errors.
# refactor the code.
