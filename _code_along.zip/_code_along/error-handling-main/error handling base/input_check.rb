class InputCheck

  def check_input(input1)

    x = 100 / input1

    puts "Hi ... I was executed."


  end

end

#rescue
#{}

#rescue => e
#puts e

#rescue StandardError => msg
